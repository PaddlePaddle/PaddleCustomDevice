// Copyright (c) 2025 PaddlePaddle Authors. All Rights Reserved.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/*
 * math_constants.h -
 *  HIP equivalent of the CUDA header of the same name
 */

#ifndef __MATH_CONSTANTS_H__
#define __MATH_CONSTANTS_H__

/* single precision constants */

#define HIPRT_INF_F        __int_as_float(0x7f800000)
#define HIPRT_NAN_F        __int_as_float(0x7fffffff)
#define HIPRT_MIN_DENORM_F __int_as_float(0x00000001)
#define HIPRT_MAX_NORMAL_F __int_as_float(0x7f7fffff)
#define HIPRT_NEG_ZERO_F   __int_as_float(0x80000000)
#define HIPRT_ZERO_F       0.0f
#define HIPRT_ONE_F        1.0f

/* double precision constants */
#define HIPRT_INF          __hiloint2double(0x7ff00000, 0x00000000)
#define HIPRT_NAN          __hiloint2double(0xfff80000, 0x00000000)

#endif
